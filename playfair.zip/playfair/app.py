from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# -----------------------
# 🔐 Playfair Cipher Logic
# -----------------------
def generate_matrix(key):
    key = key.upper().replace("J", "I")
    key = "".join([c for c in key if c.isalpha()])
    seen = set()
    matrix = []
    for char in key:
        if char not in seen:
            seen.add(char)
            matrix.append(char)
    for char in "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if char not in seen:
            seen.add(char)
            matrix.append(char)
    return [matrix[i:i + 5] for i in range(0, 25, 5)]

def find_position(matrix, letter):
    for i in range(5):
        for j in range(5):
            if matrix[i][j] == letter:
                return i, j
    return None

def prepare_text(text):
    text = text.upper().replace("J", "I")
    text = "".join([c for c in text if c.isalpha()])
    result = ""
    i = 0
    while i < len(text):
        a = text[i]
        b = text[i + 1] if i + 1 < len(text) else "X"
        if a == b:
            result += a + "X"
            i += 1
        else:
            result += a + b
            i += 2
    if len(result) % 2 != 0:
        result += "X"
    return result

def playfair_encrypt(text, key):
    matrix = generate_matrix(key)
    text = prepare_text(text)
    cipher = ""
    for i in range(0, len(text), 2):
        a, b = text[i], text[i + 1]
        r1, c1 = find_position(matrix, a)
        r2, c2 = find_position(matrix, b)
        if r1 == r2:
            cipher += matrix[r1][(c1 + 1) % 5] + matrix[r2][(c2 + 1) % 5]
        elif c1 == c2:
            cipher += matrix[(r1 + 1) % 5][c1] + matrix[(r2 + 1) % 5][c2]
        else:
            cipher += matrix[r1][c2] + matrix[r2][c1]
    return cipher

def playfair_decrypt(cipher, key):
    matrix = generate_matrix(key)
    cipher = cipher.upper().replace("J", "I")
    cipher = "".join([c for c in cipher if c.isalpha()])
    plain = ""
    for i in range(0, len(cipher), 2):
        a, b = cipher[i], cipher[i + 1]
        r1, c1 = find_position(matrix, a)
        r2, c2 = find_position(matrix, b)
        if r1 == r2:
            plain += matrix[r1][(c1 - 1) % 5] + matrix[r2][(c2 - 1) % 5]
        elif c1 == c2:
            plain += matrix[(r1 - 1) % 5][c1] + matrix[(r2 - 1) % 5][c2]
        else:
            plain += matrix[r1][c2] + matrix[r2][c1]
    return plain


# -----------------------
# 🌐 Flask Routes
# -----------------------
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/encrypt", methods=["POST"])
def encrypt():
    data = request.get_json()
    text = data.get("text", "")
    key = data.get("key", "")
    cipher = playfair_encrypt(text, key)
    return jsonify({"result": cipher})

@app.route("/decrypt", methods=["POST"])
def decrypt():
    data = request.get_json()
    text = data.get("text", "")
    key = data.get("key", "")
    plain = playfair_decrypt(text, key)
    return jsonify({"result": plain})

if __name__ == "__main__":
    app.run(debug=True)